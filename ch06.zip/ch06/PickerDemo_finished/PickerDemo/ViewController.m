//
//  ViewController.m
//  PickerDemo
//
//  Created by Simon Allardice on 11/14/13.
//  Copyright (c) 2013 Simon Allardice. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property NSArray *moods;

@end

@implementation ViewController

-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    // todo
    return [self.moods count];
}

-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    return self.moods[row];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    self.moods = @[@"Happy", @"Sad", @"Maudlin", @"Ecstatic", @"Overjoyed", @"Optimistic", @"Bewildered", @"Cynical", @"Giddy", @"Indifferent", @"Relaxed"];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
