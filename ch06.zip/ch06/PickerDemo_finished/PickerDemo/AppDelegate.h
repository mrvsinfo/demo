//
//  AppDelegate.h
//  PickerDemo
//
//  Created by Simon Allardice on 11/14/13.
//  Copyright (c) 2013 Simon Allardice. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
