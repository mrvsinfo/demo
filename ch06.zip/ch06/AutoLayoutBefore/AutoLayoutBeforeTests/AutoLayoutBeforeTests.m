//
//  AutoLayoutBeforeTests.m
//  AutoLayoutBeforeTests
//
//  Created by Simon Allardice on 10/11/13.
//  Copyright (c) 2013 Simon Allardice. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface AutoLayoutBeforeTests : XCTestCase

@end

@implementation AutoLayoutBeforeTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
