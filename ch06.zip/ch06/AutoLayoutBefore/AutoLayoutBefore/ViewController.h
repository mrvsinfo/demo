//
//  ViewController.h
//  AutoLayoutBefore
//
//  Created by Simon Allardice on 10/11/13.
//  Copyright (c) 2013 Simon Allardice. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
