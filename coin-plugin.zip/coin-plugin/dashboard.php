<?
error_reporting(E_ALL);
ini_set('display_errors', '1');


$username = 'kqueen';
$path = 'csv';


///$files = scandir($path, 1);
//print_r($files);
//$template = array();
//foreach ($files as $file){      
    
    //if(preg_match('/'.$username.'?/', $file)) {

        //if(preg_match('/total?/', $file)) {

      //      $template[] = $file;
    //    }
  //  }
//}

    
    $filename = $username.'.totals.csv';//$template[0];



    $fullfilename = $path.'/'.$username.'.totals.csv';//$template[0];


//print_r($filenamedata);

   $row = 1;
    $handle = fopen($fullfilename, "r");

?>

   <script type='text/javascript' src='http://www.google.com/jsapi'></script>
    <script type='text/javascript'>
      

      google.load('visualization', '1.1', {'packages':['annotationchart']});
      google.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = new google.visualization.DataTable();
        data.addColumn('date', 'Date');
        data.addColumn('number', 'Cash on Account');
        data.addColumn('string', 'Cash on Account title');
        data.addColumn('string', 'Cash on Account text');
        data.addColumn('number', 'Account Balance');
        data.addColumn('string', 'Account Balance title');
        data.addColumn('string', 'Account Balance text');
        data.addRows([
        <?


            while (($line = fgetcsv($handle, 2048, ",", '"')) !== FALSE) {
   // print_r( $line)."\n";
    //print_r($line);

                            echo '[new Date('.$line[1].', '.$line[2].', '.$line[3].'), '.$line[4].', undefined, undefined, '.$line[4].', undefined, undefined],';

                  

            }
 fclose($handle);




        ?>
        ]);

        var chart = new google.visualization.AnnotationChart(document.getElementById('chart_div'));

        var options = {
          displayAnnotations: true,
        };

        chart.draw(data, options);
      }
    </script>

  <div id='chart_div' style='width: 900px; height: 500px;'></div>
