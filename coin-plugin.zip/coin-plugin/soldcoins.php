<?
error_reporting(E_ALL);
ini_set('display_errors', '1');


//must be replaced with wp get username
$username = 'kqueen';
$path = 'csv/';


$files = scandir($path, 1);
//print_r($files);
$template = array();
foreach ($files as $file){      
    
    if(preg_match('/'.$username.'?/', $file)) {

        if(preg_match('/sold?/', $file)) {

            $template[] = $file;
        }
    }
}
    
    $filename = 'csv/'.$files[0];

    $filenamedata = explode(".",$filename);

    $user = $filenamedata[0];
    $type = $filenamedata[1];
    $date = $filenamedata[2];
    //$user = $filenamedata[3];

   $row = 1;
    $handle = fopen($filename, "r");
    echo '<table>';
    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
    	echo '<tr>';

        if ($data[0] != '' && $data[1] != '' && $data[3] != ''){

        echo "<tr>";
        foreach ($data as $cell) {
                echo "<td style='padding:.2em;'>" . htmlspecialchars($cell) . "</td>";
        }
        echo "</tr>\n";


        }

    	echo'</tr>';

    }

    echo '</table>';
    fclose($handle);



?>

