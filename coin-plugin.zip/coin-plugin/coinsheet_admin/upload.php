<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');

function oscimp_admin() {
    include('oscommerce_import_admin.php');
}
 
function oscimp_admin_actions() {
    add_options_page("OSCommerce Product Display", "OSCommerce Product Display", 1, "OSCommerce Product Display", "oscimp_admin");
}
 
add_action('admin_menu', 'oscimp_admin_actions');


		echo '<h1>Upload Points Sheets</h1>';


		//echo '<form action="'. plugin_dir_path() .'/uploader.php" method="post" enctype="multipart/form-data">
		echo '<form action="uploader.php" method="post" enctype="multipart/form-data">
			CSV: <input type="file" name="csv" size="65" />
			<input type="submit" name="submit" value="Submit" />
			</form>';


?> 
