<?php

error_reporting(E_ALL);
ini_set('display_errors', '1');


//if they DID upload a file...
if($_FILES['csv']['name'])
{
      //if no errors...
      if(!$_FILES['csv']['error'])
      {
            //now is the time to modify the future file name and validate the file
            $new_file_name = strtolower($_FILES['csv']['tmp_name']); //rename file

            //echo $new_file_name;
            if($_FILES['csv']['size'] > (1024000)) //can't be larger than 1 MB
            {
                  $valid_file = false;
                  $message = 'Oops!  Your file\'s size is to large.';
            }
            
            //if the file has passed the test
            if($new_file_name)
            {
                  //move it to where we want it to be
                  move_uploaded_file($_FILES['csv']['tmp_name'], '../csv/'.$_FILES['csv']['name']);
                  $message = 'Congratulations!  Your file was accepted. ';
                  echo $message.'<a href="plugin-upload.php">Click</a> to upload another<br><br> ';
                        $newestfile = $_FILES['csv']['name'];
                        $properfilename = '../csv/'.$_FILES['csv']['name'];

                       // echo '<br'.$newestfile.'<br>';

                            $filenamedata = explode(".",$newestfile);

                            $user = $filenamedata[0];
                            $type = $filenamedata[1];
                            $dirtydate = $filenamedata[2];

                            //echo $user;

                            $month1[0] = substr($dirtydate, 0, 2);
                            $dayyear[1] = substr($dirtydate, 2);

                            $dayyear0 = $dayyear[1];

                            $dayyear1[0] = substr($dayyear0, 0, 2);
                            $dayyear1[1] = substr($dayyear0, 2);

                              $month = $month1[0];
                              $day = $dayyear1[0];
                              $year = $dayyear1[1];

                  //if (strpos($newestfile,'sold') !== false) {
                  if ($type == 'sold') {
 
                            $handle = fopen($properfilename, "r");
                        //foreach (explode("\n", file_get_contents($properfilename)) as $l) {
                         while (($l = fgetcsv($handle, 2048, ",", '"')) !== FALSE) {         

                          echo '<pre>';
                         // print_r($l);
                         $newdashboardcsv = '../csv/'.$user.'.totals.csv';
                              //while (($l = fgetcsv($properfilename, 2048, ",", '"')) !== FALSE) {          

                                      if ($l[0] == 'Cash On Account' ){

                                          //print_r( $line)."\n";
                                          $dirtycashonaccount = $l[2];
                                          $cashonaccount1 = str_replace('$', '', $dirtycashonaccount);
                                          $cashonaccount2 = str_replace(',', '', $cashonaccount1);
                                          $cashonaccount = str_replace('.', '', $cashonaccount2);
                                          // '[new Date('.$year.', '.$month.', '.$day.'), '.$cashonaccount.', undefined, undefined, '.$cashonaccount.', undefined, undefined],';

                                          $cashononaccountline = "Cash on Account,".$year.",".$month.",".$day.",".$cashonaccount."\n";

                                          //file_put_contents($newdashboardcsv, implode("\n", $cashononaccountline) . "\n", FILE_APPEND);
                                          file_put_contents($newdashboardcsv, $cashononaccountline, FILE_APPEND);
                                          //
                                    }

                                    if ($l[0] == 'Account Balance' ){

                                          //print_r( $line)."\n";
                                          $dirtyaccountbalance = $l[2];
                                          $accountbalance1 = str_replace('$', '', $dirtyaccountbalance);
                                          $accountbalance2 = str_replace(',', '', $accountbalance1);
                                          $accountbalance = str_replace('.', '', $accountbalance2);
                                          //echo '[new Date('.$year.', '.$month.', '.$day.'), '.$accountbalance.', undefined, undefined, '.$accountbalance.', undefined, undefined]';

                                          $accountbalanceline = "Account Balance,".$year.",".$month.",".$day.",".$accountbalance."\n";
                                          //file_put_contents($newdashboardcsv, implode("\n", $accountbalanceline) . "\n", FILE_APPEND);
                                          file_put_contents($newdashboardcsv, $accountbalanceline, FILE_APPEND);

                                          //print_r($accountbalance);
                                    }

                                   // $str = $cashononaccountline.'|'.$accountbalanceline;
                                  //  $dashboardarr = explode("|",$str);

 echo '<pre>';
                              //}

 

                      //  $rows = explode(',', $l);
                        //str_replace('"', "", $string);

                          }

 fclose($handle); 



                        

                  }





            }

      } else {

            //set that to be the returned message
            $message = 'Ooops!  Your upload triggered the following error:  '.$_FILES['csv']['error'];

      }

}

//you get the following information for each file:
//$filename = $_FILES['field_name']['name'];
//$filezie = $_FILES['field_name']['size'];
//$filetype = $_FILES['field_name']['type'];
//$filetmpname = $_FILES['field_name']['tmp_name'];




?>

  


