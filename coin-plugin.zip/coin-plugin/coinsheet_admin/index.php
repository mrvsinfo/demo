<?php
/*
Plugin Name: Coin Sheets Uploader
Plugin URI: http://crowdgrip.com
Description: Uploading Tool for Coin Sheets CSV
Author: Crowdgrip
Author URI: http://crowdgrip.com
*/

function coinsheets_admin() {
    include('upload.php');
}
 
function oscimp_admin_actions() {
    add_options_page("Coin Sheets", "Coin Sheets", 1, "Coin Sheets", "coinsheets_admin");
}
 


?> 
